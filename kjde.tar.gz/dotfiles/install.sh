#!/bin/sh

echo KJDE automatic installation for arch based distros
echo !IMPORTANT! Please install yay aur helper before installing!
echo !IMPORTANT! Please use this script ONLY on clean install!
while true; do
	    read -p "Do you wish to proceed?" yn
	        case $yn in
			        [Yy]* ) make install; break;;
				        [Nn]* ) exit;;
					        * ) echo "Please answer yes or no.";;
						    esac
					    done

su
yay -Sy #Updating repositories
yay -Syy bspwm alacritty cava fish omf pcmanfm picom polybar sxhkd xorg dmenu feh all-repository-fonts nerd-fonts-complete #Installing required packages
cp ~/dotfiles/config/* ~/.config/* #Copying config files
cp ~/dotfiles/kjde.desktop /usr/share/xsessions/kjde.desktop
cp ~/dotfiles/kjde.sh ~/kjde.sh
cp ~/dotfiles/wallp.jpg ~/Pictures/wallp.jpg
cp /etc/X11/xinit/xinitrc ~/.xinitrc
yay -S pfetch #Installing pfetch, neofetch alternative
echo Installation complete!
echo If you want to install display manager, do it now
echo If not, use startx command, but before add folowing line to the end:
echo exec ~/kjde.sh


