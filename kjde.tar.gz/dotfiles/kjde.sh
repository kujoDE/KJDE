exec bspwm
exec sxhkd &
exec polybar example &
setkbmap pl 
feh --bg-fill ~/Pictures/wallp.png &
exec picom -b &
