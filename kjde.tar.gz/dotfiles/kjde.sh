exec bspwm
setkbmap pl &
