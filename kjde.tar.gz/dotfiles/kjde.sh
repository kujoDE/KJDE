#!/bin/sh
bspwm sxhkd & polybar left & polybar right & setkbmap pl & feh --bg-fill & ~/Pictures/wallp.png & picom -b &
