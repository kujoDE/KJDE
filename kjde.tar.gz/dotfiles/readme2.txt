if it doesn't work, it doesn't work
